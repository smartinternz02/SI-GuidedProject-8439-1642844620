package com.demian.SpringApiTest;

import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.Spliterators;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import com.fasterxml.jackson.databind.ObjectMapper;

import javassist.bytecode.Descriptor.Iterator;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;

public class ApiCall {
	
	
	
	public static void main(String[] args) throws IOException, InterruptedException {
			    
	}

}
